
# CreatorCopilot Bharat 🚀

AI-powered Regional Content Repurposing Engine for India.

## Features

- Content Understanding
- Multi-platform Repurposing
- Regional Localization
- AI-ready architecture
- Scalable backend

## API Endpoint

POST /generate

Body:
{
  "content": "Your content here"
}

## How To Run

npm install
npm start

Server runs at:
http://localhost:5000
