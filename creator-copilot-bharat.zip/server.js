
import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

/*
=========================================
CREATOR COPILOT BHARAT - AI MVP ENGINE
=========================================
*/

app.get("/", (req, res) => {
  res.json({
    message: "CreatorCopilot Bharat AI Engine Running 🚀",
  });
});

function analyzeContent(content) {
  return {
    summary: content.slice(0, 150) + "...",
    keywords: ["AI", "Digital", "Content", "Creator"],
    sentiment: "Positive",
  };
}

function generateLinkedInPost(content) {
  return `🚀 Here's what I learned today:

${content.slice(0, 200)}...

What are your thoughts?

#AI #ContentCreation #Bharat`;
}

function generateTwitterThread(content) {
  return `🧵 Thread:

1/ ${content.slice(0, 100)}

2/ Key takeaway: Consistency + AI = Scale

3/ Follow for more insights 🚀`;
}

function generateBlogArticle(content) {
  return `
# AI & The Future of Content Creation

${content}

## Conclusion
AI is transforming how creators scale across platforms.
`;
}

function translateToHindi(content) {
  return `🇮🇳 हिंदी संस्करण:

${content}

(Translated version placeholder)`;
}

function translateToMarathi(content) {
  return `🇮🇳 मराठी आवृत्ती:

${content}

(Translated version placeholder)`;
}

app.post("/generate", (req, res) => {
  const { content } = req.body;

  if (!content) {
    return res.status(400).json({
      error: "Content is required",
    });
  }

  const analysis = analyzeContent(content);

  const response = {
    analysis,
    repurposed: {
      linkedin: generateLinkedInPost(content),
      twitter: generateTwitterThread(content),
      blog: generateBlogArticle(content),
    },
    localization: {
      hindi: translateToHindi(content),
      marathi: translateToMarathi(content),
    },
  };

  res.json(response);
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
